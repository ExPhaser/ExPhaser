interface IProjectile {
  //create(): void;
  update(time: number, delta: number): void;

}
export default IProjectile;
