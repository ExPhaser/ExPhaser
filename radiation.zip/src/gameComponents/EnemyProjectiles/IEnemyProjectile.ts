interface IEnemyProjectile {
  //create(): void;
  update(time: number, delta: number): void;

}
export default IEnemyProjectile;
