interface IPlayer {
 
  update(time: number, delta: number): void;
 
}
export default IPlayer;
